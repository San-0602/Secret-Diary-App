package com.example.secretdiaryapp;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText secretInput, passwordInput;
    Button saveButton, unlockButton;
    TextView resultText;

    String storedSecret = ""; // This will hold the garbled version of the secret
    String originalSecret = ""; // This will hold the original secret
    final String correctPassword = "OpenSesame"; // Set your secret password here

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        secretInput = findViewById(R.id.secretInput);
        passwordInput = findViewById(R.id.passwordInput);
        saveButton = findViewById(R.id.saveButton);
        unlockButton = findViewById(R.id.unlockButton);  // Update this line
        resultText = findViewById(R.id.decryptedText);  // Updated to match your XML ID

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String secret = secretInput.getText().toString();

                if (secret.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Bruh. You really thought you could save *nothing*?", Toast.LENGTH_SHORT).show();
                    return;
                }

                originalSecret = secret; // Store the original secret
                storedSecret = garbleText(secret); // Garble the secret
                Toast.makeText(MainActivity.this, "Shhh... Secret saved (or scrambled).", Toast.LENGTH_SHORT).show();
                secretInput.setText("");
            }
        });

        unlockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredPassword = passwordInput.getText().toString();

                if (enteredPassword.equals(correctPassword)) {
                    resultText.setText("Your secret was:\n" + originalSecret); // Show the original secret
                    Toast.makeText(MainActivity.this, "Access granted. Welcome back, Agent 007.", Toast.LENGTH_SHORT).show();
                } else {
                    resultText.setText("x&@7!#rfa8h$@##~garbled~!!@#");
                    Toast.makeText(MainActivity.this, "Incorrect. This isn't a guessing game, it's a *diary*, genius.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Simulate encryption (for fun)
    private String garbleText(String input) {
        StringBuilder garbled = new StringBuilder();
        for (char c : input.toCharArray()) {
            garbled.append((char)(c + 3)); // Shift each character by 3 (Caesar Cipher style)
        }
        return garbled.toString();
    }
}
